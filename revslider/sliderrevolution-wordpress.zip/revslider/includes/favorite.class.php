<?php
/**
 * @author    ThemePunch <info@themepunch.com>
 * @link      https://www.themepunch.com/
 * @copyright 2024 ThemePunch
 */

if(!defined('ABSPATH')) exit();

/**
 * Favorites of the editor UI (modules, templates, objects, …), stored per type in the
 * ['favorites']['favorites'] option.
 */
class RevSliderFavorite extends RevSliderFunctions {

	/**
	 * change the setting of a favorization
	 * @param string $do
	 * @param string $type
	 * @param mixed $id
	 * @return array
	 **/
	public function set_favorite($do, $type, $id){
		$fav = $this->get_options(['favorites', 'favorites'], []);
		$id	 = esc_attr($id);

		if(!isset($fav[$type])) $fav[$type] = [];
		$key = array_search($id, $fav[$type]);
		if($key === false){
			if($do == 'add') $fav[$type][] = $id;
		}elseif($do == 'remove'){
			unset($fav[$type][$key]);
		}elseif($do == 'replace'){
			$fav[$type] = $id;
		}
		$this->update_option(['favorites', 'favorites'], $fav);
		
		return $fav;
	}
	
	/**
	 * get a certain favorite type
	 * @param string $type
	 * @return array
	 **/
	public function get_favorite($type){
		$fav = $this->get_options(['favorites', 'favorites'], []);
		return $this->get_val($fav, $type, []);
	}
	
	/**
	 * return if certain element is in favorites
	 * @param string $type
	 * @param mixed $id
	 * @return bool
	 **/
	public function is_favorite($type, $id){
		$favs = $this->get_favorite($type);

		return array_search(esc_attr($id), $favs, true) !== false; //normalize $id like set_favorite() stores it, then strict-compare
	}
}